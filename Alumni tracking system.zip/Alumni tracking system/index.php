<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel="icon" href="alumni logoo.jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      
    }

    .navbar {
      overflow: hidden;
      font-family:sans-serif; 
  background: -webkit-linear-gradient(to right, #155799, #159957); 
  background: linear-gradient(to right, #155799, #159957); 
  color:whitesmoke;
  
    }

    .navbar a {
      float: right;
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }

    .navbar a:hover {
      background-color: #ddd;
      color: orangered;
    }
    .navbar ul:hover{
        
      color: white;
    }
    p {
  text-align: left;
  font-size: 20px;
  color: white;
}
body{
    background-image: url('front page.jpg');
}
  </style>
</head>
<body>
  <div class="navbar">
 
  &nbsp&nbsp&nbsp&nbsp<a href="home.php"><b>Alumni Tracking System</b></a>  &nbsp&nbsp&nbsp&nbsp
    <a href="home.php">Home</a>  
    <a href="alumni.php">Alumni</a>
    <a href="gallery.php">Gallery</a>
    <a href="event.php">Event</a>
    <a href="about.php">About</a>
    <a href="login.php">Login&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
    <a href="chatbox.php">  <i style="font-size:28px;color:white" class="fa"> 	&#xf27a</i></a>   &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp






     
   
 
    
    
  
      
     


  

     <script type="text/javascript">
   
   alert("Wellcome to Alumni tracking system")
   </script>
  
    </div>
 

</body>
</html>
