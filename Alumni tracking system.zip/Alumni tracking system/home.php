<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      
    }

    .navbar {
      overflow: hidden;
      font-family:sans-serif; 
  background: -webkit-linear-gradient(to right, #155799, #159957); 
  background: linear-gradient(to right, #155799, #159957); 
  color:whitesmoke;
  
    }

    .navbar a {
      float: right;
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }

    .navbar a:hover {
      background-color: #ddd;
      color: orangered;
    }
    .navbar ul:hover{
        
      color: white;
    }
    p {
  text-align: left;
  font-size: 20px;
  color: white;
}
body{
    background-image: url('front page.jpg');
}
  </style>
</head>
<body>
  <div class="navbar">
    <a href="login.php">Login&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a>
    <a href="contact.php">Contact</a>
    <a href="about.php">About</a>
    <a href="event.php">Event</a>
    <a href="gallery.php">Gallery</a>
    <a href="alumni.php">Alumni</a>
    <a href="home.php">Home</a>    
 
    

  
      <p class="text-muted">
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <b>Alumni Tracking System </b>

     </p> 
     


  

     <script type="text/javascript">
   
   alert("Wellcome to Alumni tracking system")
   </script>
  
    </div>
 

</body>
</html>
