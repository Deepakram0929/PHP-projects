<?php
        session_start();

        $connection = mysqli_connect('localhost','root','');

        mysqli_select_db($connection, 'school');

        if(isset($_POST['update']))
        {
            $rollno =  $_POST['rollno'];
            $name =  $_POST['name'];
            $class =  $_POST['class'];
            $section =  $_POST['section'];
            $phonenumber =  $_POST['phonenumber'];
            $address =  $_POST['address'];
    
            $updatequery = "UPDATE student SET name = '$name',class='$class',section='$section',
            phonenumber='$phonenumber',address='$address' WHERE rollno = '$rollno'";


           $run  = mysqli_query($connection, $updatequery);

           if($run) 
           {
                echo " Student Data Updated";
           }
        }
       

    ?>