<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STUDENTS DETAILS</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>

    <?php
        session_start();

        $connection = mysqli_connect('localhost','root','');

        mysqli_select_db($connection, 'school');
        $rollno =  $_POST['rollno'];
        $name =  $_POST['name'];
        $class =  $_POST['class'];
        $section =  $_POST['section'];
        $phonenumber =  $_POST['phonenumber'];
        $address =  $_POST['address'];

        $data ="INSERT INTO student (rollno, name,class, section, phonenumber, address)
        VALUES ('$rollno', '$name', '$class',  '$section', '$phonenumber', '$address');";


        mysqli_query($connection, $data);
        echo "Data Inserted";

    ?>


    
</body>
</html>
