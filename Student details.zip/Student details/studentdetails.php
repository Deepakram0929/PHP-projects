<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Data</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <h1 id  align="center">Student Data</h1>
    
    <?php
        session_start();

        $connection = mysqli_connect('localhost','root','');

        mysqli_select_db($connection, 'school');

        $studentdata = "SELECT * FROM student;";

        $dataResult = mysqli_query( $connection,  $studentdata);

        // while($rows  = mysqli_fetch_assoc($dataResult)){
        //     echo $rows['name'];
        //     echo "   ";
        //     echo $rows['address'];
        //     echo "<br>";
        // }
    ?>

<table width="90%" border="1">
        <tr>
            <th>Roll No</th>
            <th>Student Name</th>
            <th>Class</th>
            <th>Section</th>
            <th>Phone Number</th>
            <th>Address</th>
        </tr>

        <?php 
            while($rows  = mysqli_fetch_assoc($dataResult)){
        ?>
        <tr>
                <td> <?php echo $rows['rollno']; ?> </td>
                <td> <?php echo $rows['name']; ?> </td>
                <td> <?php echo $rows['class']; ?> </td>
                <td> <?php echo $rows['section']; ?> </td>
                <td> <?php echo $rows['phonenumber']; ?> </td>
                <td> <?php echo $rows['address']; ?> </td>
        </tr>


        <?php }?>

    </table>


    <h2 align="center">Delete Student</h2>

    <form action="studentdelete.php" method="POST">
    <input type="text" placeholder="roll number" name="rollno">
    <button type="submit" name="delete">Delete</button>
    </form>
    
    <!--DELETE FROM student WHERE rollno = 1; -->

    <h2 align="center">Update Student</h2>
    <style>
        body{
                background-color:rgb(43, 153, 226);
        }
        tr td{
              color:white;
             }
       
    </style>
    
    <form action="studentupdate.php" method="POST">
    <table align="center" width="80%"  >
        <tr>
                <td><label>Roll No</label></td>
                <td><input type="text" name="rollno" ></td>
        </tr>

        <tr>
                <td><label>Name</label></td>
                <td><input type="text" name="name"></td>
        </tr>

        <tr>
                <td><label>Class</label></td>
                <td><input type="text" name="class"></td>
        </tr>


        <tr>
                <td><label>Section</label></td>
                <td><input type="text" name="section"></td>
        </tr>

        <tr>
                <td><label>PhoneNumber</label></td>
                <td><input type="text" name="phonenumber"></td>
        </tr>

        <tr>
                <td><label>Address</label></td>
                <td><input type="text" name="address"></td>
        </tr>
        <tr>
                <td> </td>
                <td><input type="submit" name="update"></td>
        </tr>
    </table>
            </form>

</body>
</html>