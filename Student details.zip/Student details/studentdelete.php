<?php
        session_start();

        $connection = mysqli_connect('localhost','root','');

        mysqli_select_db($connection, 'school');

        if(isset($_POST['delete']))
        {
            $rollno = $_POST['rollno'];
            $deletequery = "DELETE FROM student WHERE rollno = '$rollno'";

           $run  = mysqli_query($connection, $deletequery);

           if($run) 
           {
                echo " Student Data Deleted";
           }
        }
       

    ?>