<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
   <a href="./studentdetails.php">View Student Data</a>
   <form action="valid.php" method="POST">

   <h1 align="center">Student Information</h1>
   <style>
        body{
                background-image:url('');
        }
   </style>

   <table align="center" width="10%"  >
        <tr>
                <td><label>Roll No</label></td>
                <td><input type="text" name="rollno" ></td>
        </tr>

        <tr>
                <td><label>Name</label></td>
                <td><input type="text" name="name"></td>
        </tr>

        <tr>
                <td><label>Class</label></td>
                <td><input type="text" name="class"></td>
        </tr>


        <tr>
                <td><label>Section</label></td>
                <td><input type="text" name="section"></td>
        </tr>

        <tr>
                <td><label>PhoneNumber</label></td>
                <td><input type="text" name="phonenumber"></td>
        </tr>

        <tr>
                <td><label>Address</label></td>
                <td><input type="text" name="address"></td>
        </tr>
        <tr>
                <td> </td>
                <td><input type="submit" ></td>
        </tr>
    </table>





    </form>

    
</body>
</html>